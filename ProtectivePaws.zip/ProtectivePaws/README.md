# Protective Paws

Protective Paws is an inventory management system that can aid the management team of animal shelters in maintaining and managing information about the shelter. It facilitates in keeping record of the animals, their supplies and personnel available to care for them. The system aims to eradicate neglect of sheltered animals by providing the staff with useful information to ensure that all the animal’s needs are met.

## Technologies Used

- Eclipse IDE for Enterprise Java and Web Developers
- Java
- Java Servlets
- JSP
- MySQL 
- Corel Draw
